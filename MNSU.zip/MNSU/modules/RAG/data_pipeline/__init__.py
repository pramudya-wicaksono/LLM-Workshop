"""
Data Pipeline Module for Professor Search System
Handles data processing, embedding generation, and FAISS indexing
"""

from .faiss_index_builder import FAISSIndexBuilder
from .professor_search import ProfessorSearch

__all__ = ['FAISSIndexBuilder', 'ProfessorSearch']

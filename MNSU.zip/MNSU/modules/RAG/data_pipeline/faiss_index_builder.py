"""
Build FAISS Vector Database from RateMyProfessors Data
Uses OpenAI embeddings to create a searchable vector database
"""

from dotenv import load_dotenv
import json
import os

import numpy as np
import openai
import faiss
import pickle


# Load environment variables
load_dotenv()
openai.api_key = os.getenv('OPENAI_API_KEY')


class FAISSIndexBuilder:
    def __init__(self, json_file: str = None):
        # Get the directory where this script is located
        script_dir = os.path.dirname(os.path.abspath(__file__))
        self.json_file = json_file or os.path.join(script_dir, "professors_index.json")
        self.professors_data = []
        self.documents = []
        self.embeddings = []
        self.index = None
        self.embedding_model = "text-embedding-3-small"  # OpenAI's latest small embedding model
        self.script_dir = script_dir
        
    def load_data(self):
        """
        Load professor data from JSON file
        """
        with open(self.json_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            self.professors_data = data['professors']
    
    def create_documents(self):
        """
        Create text documents from professor data
        Each document contains all relevant information about a professor
        """
        for prof in self.professors_data:
            # Build comprehensive document text
            doc_parts = []
            
            # Basic info
            doc_parts.append(f"Professor: {prof['name']}")
            doc_parts.append(f"Department: {prof['department']}")
            doc_parts.append(f"Overall Rating: {prof.get('overall_rating', prof['rating'])}/5.0")
            doc_parts.append(f"Total Ratings: {prof.get('total_ratings', prof['rating_count'])}")
            doc_parts.append(f"Would Take Again: {prof.get('would_take_again', 'N/A')}")
            doc_parts.append(f"Difficulty Level: {prof.get('difficulty_level', prof.get('difficulty', 'N/A'))}")
            
            # Add tags
            if prof.get('top_tags'):
                doc_parts.append(f"Student Tags: {', '.join(prof['top_tags'])}")
            
            # Add rating distribution
            if prof.get('rating_distribution'):
                dist = prof['rating_distribution']
                doc_parts.append(f"Rating Distribution: {dist}")
            
            # Add reviews
            if prof.get('reviews'):
                doc_parts.append(f"\nStudent Reviews ({len(prof['reviews'])} shown):")
                for i, review in enumerate(prof['reviews'], 1):
                    review_text = f"\nReview {i}:"
                    review_text += f" Class: {review.get('class', 'N/A')}."
                    review_text += f" Date: {review.get('date', 'N/A')}."
                    review_text += f" Quality: {review.get('quality', 'N/A')}, Difficulty: {review.get('difficulty', 'N/A')}."
                    
                    if review.get('comment'):
                        review_text += f" Comment: {review['comment']}"
                    
                    if review.get('tags'):
                        review_text += f" Tags: {', '.join(review['tags'])}."
                    
                    doc_parts.append(review_text)
            
            # Combine all parts
            document = "\n".join(doc_parts)
            
            self.documents.append({
                'id': prof['id'],
                'name': prof['name'],
                'department': prof['department'],
                'text': document,
                'url': prof['url'],
                'metadata': {
                    'rating': prof.get('overall_rating', prof['rating']),
                    'would_take_again': prof.get('would_take_again', 'N/A'),
                    'difficulty': prof.get('difficulty_level', prof.get('difficulty', 'N/A'))
                }
            })
        
    
    def get_embeddings(self, batch_size: int = 100):
        """
        Get embeddings from OpenAI API
        Processes in batches to handle rate limits
        """
        
        all_embeddings = []
        
        for i in range(0, len(self.documents), batch_size):
            batch = self.documents[i:i + batch_size]
            batch_texts = [doc['text'] for doc in batch]
            
            try:
                response = openai.embeddings.create(
                    model=self.embedding_model,
                    input=batch_texts
                )
                
                batch_embeddings = [item.embedding for item in response.data]
                all_embeddings.extend(batch_embeddings)
                
            except Exception as e:
                # Add zero embeddings as fallback
                embedding_dim = 1536  # dimension for text-embedding-3-small
                all_embeddings.extend([np.zeros(embedding_dim).tolist() for _ in batch])
        
        self.embeddings = np.array(all_embeddings, dtype='float32')
    
    def build_faiss_index(
        self
        ):
        """Build FAISS index from embeddings"""
        
        dimension = self.embeddings.shape[1]
        
        # Create FAISS index
        # Using IndexFlatL2 for exact search (good for smaller datasets)
        # For larger datasets, consider IndexIVFFlat or IndexHNSWFlat
        self.index = faiss.IndexFlatL2(dimension)
        
        # Add embeddings to index
        self.index.add(self.embeddings)
        
    
    def save_index(
            self, 
            index_file: str = None, 
            metadata_file: str = None
        ) -> None:
        """
        Save FAISS index and metadata to disk
        """
        # Use default paths in the same directory as this script
        index_file = index_file or os.path.join(self.script_dir, "professors_faiss.index")
        metadata_file = metadata_file or os.path.join(self.script_dir, "professors_metadata.pkl")
        
        # Save FAISS index
        faiss.write_index(self.index, index_file)
        
        # Save documents metadata
        with open(metadata_file, 'wb') as f:
            pickle.dump(self.documents, f)
    
    def build_complete_index(self):
        """
        Run the complete pipeline    
        """
        self.load_data()
        self.create_documents()
        self.get_embeddings()
        self.build_faiss_index()
        self.save_index()
        

def main():
    """
    Main function - builds the FAISS index
    """
    builder = FAISSIndexBuilder()
    builder.build_complete_index()
    print("\n[SUCCESS] FAISS index built successfully!")


if __name__ == "__main__":
    main()

"""
Professor Search Module
Provides semantic search interface for the FAISS vector database
"""

from dotenv import load_dotenv
import os
from typing import List, Dict

import faiss
import numpy as np
import openai
import pickle


# Load environment variables
load_dotenv()
openai.api_key = os.getenv('OPENAI_API_KEY')


class ProfessorSearch:
    """
    Search interface for the FAISS index
    """
    def __init__(self, index_file: str = None,
                 metadata_file: str = None):
        load_dotenv()
        openai.api_key = os.getenv('OPENAI_API_KEY')
        
        # Get the directory where this script is located
        script_dir = os.path.dirname(os.path.abspath(__file__))
        index_file = index_file or os.path.join(script_dir, "professors_faiss.index")
        metadata_file = metadata_file or os.path.join(script_dir, "professors_metadata.pkl")
        
        self.embedding_model = "text-embedding-3-small"
        self.index = faiss.read_index(index_file)
        
        with open(metadata_file, 'rb') as f:
            self.documents = pickle.load(f)
        
        print(f"[OK] Loaded FAISS index with {self.index.ntotal} vectors")
        print(f"[OK] Loaded {len(self.documents)} professor profiles")
    
    def search(self, query: str, k: int = 5) -> List[Dict]:
        """
        Search for professors using semantic similarity
        
        Args:
            query: Natural language search query
            k: Number of results to return
        
        Returns:
            List of professor documents with similarity scores
        """

        # Get query embedding
        response = openai.embeddings.create(
            model=self.embedding_model,
            input=[query]
        )
        query_embedding = np.array([response.data[0].embedding], dtype='float32')
        
        # Search FAISS index
        distances, indices = self.index.search(query_embedding, k)
        
        # Prepare results
        results = []
        for i, (dist, idx) in enumerate(zip(distances[0], indices[0])):
            if idx < len(self.documents):
                doc = self.documents[idx].copy()
                doc['similarity_score'] = float(1 / (1 + dist))  # Convert distance to similarity
                doc['rank'] = i + 1
                results.append(doc)
        
        return results
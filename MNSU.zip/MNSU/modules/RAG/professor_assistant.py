"""
Professor Assistant - RAG-based Q&A system for MNSU professors
Uses FAISS vector database for semantic search and OpenAI for responses
"""

import os
from typing import List, Dict
from dotenv import load_dotenv

import openai

from data_pipeline.professor_search import ProfessorSearch


# Load environment variables
load_dotenv()
openai.api_key = os.getenv('OPENAI_API_KEY')


class ProfessorAssistant:
    """
    RAG-based assistant for answering questions about MNSU professors
    """
    
    def __init__(self):
        """
        Initialize the assistant with FAISS search
        """

        # Get paths relative to this file
        data_pipeline_dir = os.path.join(os.path.dirname(__file__), 'data_pipeline')
        index_file = os.path.join(data_pipeline_dir, 'professors_faiss.index')
        metadata_file = os.path.join(data_pipeline_dir, 'professors_metadata.pkl')
        
        # Initialize search engine
        self.searcher = ProfessorSearch(index_file=index_file, metadata_file=metadata_file)
        self.conversation_history = []
            
    def search_professors(self, query: str, k: int = 10000) -> List[Dict]:
        """
        Search for relevant professors based on query
        
        Args:
            query: User's question or search query
            k: Number of professors to retrieve
            
        Returns:
            List of relevant professor documents
        """
        return self.searcher.search(query, k=k)
    
    def format_context(self, results: List[Dict]) -> str:
        """
        Format search results into context for the LLM
        
        Args:
            results: List of professor documents from search
            
        Returns:
            Formatted context string
        """
        context_parts = []
        
        for i, result in enumerate(results, 1):
            context_parts.append(f"\n--- Professor {i} ---")
            context_parts.append(f"Name: {result['name']}")
            context_parts.append(f"Department: {result['department']}")
            context_parts.append(f"Rating: {result['metadata']['rating']}/5.0")
            context_parts.append(f"Would Take Again: {result['metadata']['would_take_again']}")
            context_parts.append(f"Difficulty: {result['metadata']['difficulty']}")
            context_parts.append(f"\nDetailed Information:")
            context_parts.append(result['text'][:1500])  # Limit text length
            context_parts.append(f"\nProfile URL: {result['url']}")
        
        return "\n".join(context_parts)
    
    def answer_question(self, question: str, model: str = "gpt-4o-mini") -> Dict:
        """
        Answer a question about professors using RAG
        
        Args:
            question: User's question
            model: OpenAI model to use
            
        Returns:
            Dictionary with answer and sources
        """
        results = self.search_professors(question, k=3)
        
        if not results:
            error_response = "I couldn't find any relevant professor information for your question."
            # Append to conversation history
            self.conversation_history.append({"role": "user", "content": question})
            self.conversation_history.append({"role": "assistant", "content": error_response})
            return {
                'answer': error_response,
                'sources': []
            }
        
        # Step 2: Format context
        context = self.format_context(results)
        
        
        system_prompt = """
            You are a helpful academic advisor assistant for Wisonsin State University, Appleton. 
            Your role is to help students find the right professors based on their needs and preferences.

            Use the provided professor information to give accurate, helpful recommendations. 
            Always cite specific details from the professor profiles (ratings, student reviews, etc.).
            Be honest about both strengths and weaknesses.
            If asked about a specific professor, provide comprehensive information.
            If asked for recommendations, suggest 2-3 professors and explain why they're good fits.
            """

        user_prompt = f"""
            Based on the following professor information, please answer this question:

            Question: {question}

            Professor Information:
            {context}

            Please provide a helpful, detailed answer. Include specific professors' 
            names and cite relevant details from their profiles.
            """

        try:
            # Build messages list with conversation history
            messages = [{"role": "system", "content": system_prompt}]
            
            # Append previous conversation history
            messages.extend(self.conversation_history)
            
            # Add current user question with context
            messages.append({"role": "user", "content": user_prompt})
            
            response = openai.chat.completions.create(
                model=model,
                messages=messages,
                temperature=0.2,
                max_tokens=1000
            )
            
            answer = response.choices[0].message.content
            
            # Append current exchange to conversation history
            self.conversation_history.append({"role": "user", "content": user_prompt})
            self.conversation_history.append({"role": "assistant", "content": answer})
            
            return {
                'answer': answer,
            }
            
        except Exception as e:
            print(f"Error generating answer: {e}")
            error_message = f"I encountered an error: {e}"
            # Append error to conversation history
            self.conversation_history.append({"role": "user", "content": user_prompt})
            self.conversation_history.append({"role": "assistant", "content": error_message})
            return {
                'answer': error_message,
                'sources': []
            }
    
    def chat(self):
        """
        Interactive chat mode
        """
        
        while True:
            question = input("\n🎓 Your question: ").strip()
            
            if question.lower() in ['quit', 'exit', 'q']:
                print("\nGoodbye! Good luck with your classes!")
                break
            
            if not question:
                print("Please ask a question.")
                continue
            
            # Get answer
            result = self.answer_question(question)
            
            # Display answer
            print("Assistant:")
            print(result['answer'])
            

def main():
    """
    Main function
    """

    # Initialize assistant
    assistant = ProfessorAssistant()
    assistant.chat()


if __name__ == "__main__":
    main()
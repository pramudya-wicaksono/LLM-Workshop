import os
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()


SYSTEM_MESSAGE = "You are a helpful assistant."


class NaiveChat:
    def __init__(self):
        self.client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
    
    def chat(self, user_message):
        response = self.client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": SYSTEM_MESSAGE},
                {"role": "user", "content": user_message}
            ]
        )
        return response.choices[0].message.content
